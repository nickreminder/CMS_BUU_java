jar cvfm translator.jar manifest.txt com
