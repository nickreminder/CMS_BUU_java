package com.edi.translation.constants;

public class IndexConstants {
	public static final int EXCHNAGE_ASSIGNED_SUBSCRIBER_ID_INDEX = 20;
	public static final int SUBSCRIBER_INDICATOR_INDEX = 18;
	public static final int HIOS_ID_INDEX = 4;
	public static final int INSURANCE_LINE_OF_BUSINESS_INDEX = 95;
	public static final int EXCHANGE_ASSIGNED_POLICY_NUMBER_INDEX = 68;
	public static final int QHP_IENTIFIER_INDEX = 66;
	public static final int BATCH_ID_INDEX = 106;
	public static final int RECORD_ID_INDEX = 107;
}
